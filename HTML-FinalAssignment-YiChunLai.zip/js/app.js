$(document).foundation()

